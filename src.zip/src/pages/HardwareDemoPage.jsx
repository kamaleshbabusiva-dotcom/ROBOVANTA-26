import React, { useState, useEffect } from 'react';
import { Cpu, Zap, Activity, Waves, Power, Settings, Settings2 } from 'lucide-react';

export default function HardwareDemoPage() {
    const [systemActive, setSystemActive] = useState(false);
    const [particles, setParticles] = useState([]);

    // Simulate flowing water particles
    useEffect(() => {
        if (!systemActive) return;

        const interval = setInterval(() => {
            const id = Date.now();
            setParticles(prev => [
                ...prev.slice(-15),
                { id, x: 0, y: Math.random() * 80 + 10, isPlastic: Math.random() > 0.7 }
            ]);
        }, 300);

        return () => clearInterval(interval);
    }, [systemActive]);

    return (
        <div className="space-y-6 animate-fade-in">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="font-display text-3xl font-bold text-white flex items-center gap-3">
                        <Cpu className="w-8 h-8 text-emerald-400" /> Hardware Demo
                    </h1>
                    <p className="text-gray-400 mt-1">Interactive visualization of our inline Spectroscopy sensor</p>
                </div>
                <button
                    onClick={() => setSystemActive(!systemActive)}
                    className={`btn-${systemActive ? 'secondary' : 'primary'} flex items-center gap-2`}
                >
                    <Power className={`w-5 h-5 ${systemActive ? 'text-red-400' : 'text-emerald-400'}`} />
                    {systemActive ? 'Shut Down Unit' : 'Power On Unit'}
                </button>
            </div>

            <div className="grid lg:grid-cols-3 gap-6">
                {/* Main Hardware Diagram */}
                <div className="lg:col-span-2 glass-card p-8 min-h-[500px] flex flex-col justify-center relative overflow-hidden">
                    <h3 className="absolute top-6 left-6 font-display font-bold text-gray-500 uppercase tracking-widest text-xs">
                        Optical Flow Cell Diagram
                    </h3>

                    {/* Water Flow Background */}
                    <div className="absolute inset-0 top-1/2 -translate-y-1/2 h-32 bg-blue-900/10 border-y border-blue-500/10 overflow-hidden">
                        {systemActive && (
                            <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/water.png')] animate-[slide-right_5s_linear_infinite] opacity-20" />
                        )}
                        {/* Particles */}
                        {particles.map((p, i) => (
                            <div
                                key={p.id}
                                className={`absolute w-3 h-3 rounded-full transition-all duration-3000 ease-linear shadow-lg ${p.isPlastic ? 'bg-orange-500 shadow-orange-500/50 scale-150' : 'bg-cyan-500 shadow-cyan-500/50'
                                    }`}
                                style={{
                                    left: `${i * 10}%`, // Simplified animation distribution
                                    top: `${p.y}%`,
                                    transition: 'left 2s linear'
                                }}
                            />
                        ))}
                    </div>

                    {/* Hardware Components */}
                    <div className="relative z-10 flex items-center justify-between px-10">
                        {/* Light Source */}
                        <div className="text-center group">
                            <div className={`w-20 h-20 mx-auto rounded-xl border flex items-center justify-center mb-4 transition-all ${systemActive ? 'bg-yellow-500/10 border-yellow-500/30' : 'bg-dark-900 border-white/5'
                                }`}>
                                <Zap className={`w-8 h-8 ${systemActive ? 'text-yellow-400' : 'text-gray-600'}`} />
                            </div>
                            <div className="text-xs font-bold uppercase tracking-wider text-gray-400 group-hover:text-yellow-400 transition-colors">Infrared Laser</div>
                        </div>

                        {/* Laser Beam */}
                        <div className="flex-1 h-0.5 mx-4 flex items-center justify-center">
                            {systemActive && (
                                <div className="w-full h-1 bg-yellow-400/50 animate-pulse shadow-[0_0_15px_rgba(250,204,21,0.5)]" />
                            )}
                        </div>

                        {/* Sensor */}
                        <div className="text-center group">
                            <div className={`w-20 h-20 mx-auto rounded-xl border flex items-center justify-center mb-4 transition-all ${systemActive ? 'bg-emerald-500/10 border-emerald-500/30' : 'bg-dark-900 border-white/5'
                                }`}>
                                <Activity className={`w-8 h-8 ${systemActive ? 'text-emerald-400' : 'text-gray-600'}`} />
                            </div>
                            <div className="text-xs font-bold uppercase tracking-wider text-gray-400 group-hover:text-emerald-400 transition-colors">Spectrometer</div>
                        </div>

                        {/* Data Link */}
                        <div className="flex-1 h-0.5 mx-4 border-t border-dashed border-gray-600 relative">
                            {systemActive && (
                                <div className="absolute top-[-3px] left-0 w-2 h-2 rounded-full bg-emerald-400 animate-[bounce-right_1s_infinite]" />
                            )}
                        </div>

                        {/* Edge AI Unit */}
                        <div className="text-center group">
                            <div className={`w-20 h-20 mx-auto rounded-xl border flex items-center justify-center mb-4 transition-all ${systemActive ? 'bg-purple-500/10 border-purple-500/30' : 'bg-dark-900 border-white/5'
                                }`}>
                                <Cpu className={`w-8 h-8 ${systemActive ? 'text-purple-400' : 'text-gray-600'}`} />
                            </div>
                            <div className="text-xs font-bold uppercase tracking-wider text-gray-400 group-hover:text-purple-400 transition-colors">Edge AI CPU</div>
                        </div>
                    </div>
                </div>

                {/* Operations Panel */}
                <div className="space-y-6">
                    <div className="glass-card p-6">
                        <h3 className="font-display font-bold text-white mb-4 flex items-center gap-2">
                            <Settings className="w-5 h-5 text-gray-400" /> Sensor Status
                        </h3>
                        <div className="space-y-4">
                            <div className="flex justify-between items-center p-3 rounded-xl bg-white/5">
                                <span className="text-xs uppercase text-gray-500 font-bold">Flow Cell</span>
                                <span className={`text-xs font-bold px-2 py-1 rounded ${systemActive ? 'bg-blue-500/20 text-blue-400' : 'bg-gray-800 text-gray-500'}`}>
                                    {systemActive ? 'Active 1.2 L/m' : 'Idle'}
                                </span>
                            </div>
                            <div className="flex justify-between items-center p-3 rounded-xl bg-white/5">
                                <span className="text-xs uppercase text-gray-500 font-bold">Laser Diode</span>
                                <span className={`text-xs font-bold px-2 py-1 rounded ${systemActive ? 'bg-yellow-500/20 text-yellow-400' : 'bg-gray-800 text-gray-500'}`}>
                                    {systemActive ? 'Calibrated' : 'Offline'}
                                </span>
                            </div>
                            <div className="flex justify-between items-center p-3 rounded-xl bg-white/5">
                                <span className="text-xs uppercase text-gray-500 font-bold">AI Database</span>
                                <span className={`text-xs font-bold px-2 py-1 rounded ${systemActive ? 'bg-purple-500/20 text-purple-400' : 'bg-gray-800 text-gray-500'}`}>
                                    {systemActive ? 'Connected (v4.2)' : 'Offline'}
                                </span>
                            </div>
                        </div>
                    </div>

                    <div className="glass-card p-6 border-blue-500/20 bg-blue-500/5">
                        <h3 className="font-display font-bold text-white mb-2 flex items-center gap-2">
                            <Settings2 className="w-5 h-5 text-blue-400" /> How it Works
                        </h3>
                        <ol className="list-decimal pl-5 space-y-2 text-sm text-gray-400 mt-4">
                            <li>Water is pumped continuously through the optical flow cell.</li>
                            <li>Infrared laser illuminates the water passing through.</li>
                            <li>The Spectrometer reads the reflected/absorbed light wavelengths.</li>
                            <li>The Edge AI matches the spectral signatures against known microplastics.</li>
                        </ol>
                    </div>
                </div>
            </div>
            {/* Styles for animations */}
            <style jsx>{`
                @keyframes slide-right {
                    from { background-position: 0 0; }
                    to { background-position: 200px 0; }
                }
                @keyframes bounce-right {
                    0% { left: 0; opacity: 1; }
                    50% { opacity: 0.5; }
                    100% { left: 100%; opacity: 0; }
                }
            `}</style>
        </div>
    );
}
