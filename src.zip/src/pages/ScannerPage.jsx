import React, { useState, useEffect } from 'react';
import { Camera, RefreshCw, Layers, ShieldCheck, AlertTriangle, Droplets } from 'lucide-react';

export default function ScannerPage() {
    const [scanning, setScanning] = useState(false);
    const [progress, setProgress] = useState(0);
    const [result, setResult] = useState(null);

    const startScan = () => {
        setScanning(true);
        setProgress(0);
        setResult(null);
    };

    useEffect(() => {
        if (scanning) {
            const interval = setInterval(() => {
                setProgress(p => {
                    if (p >= 100) {
                        clearInterval(interval);
                        setScanning(false);
                        setResult({
                            purity: (Math.random() * 10 + 85).toFixed(1), // 85-95%
                            microplastics: Math.floor(Math.random() * 500 + 100),
                            status: Math.random() > 0.3 ? 'Safe' : 'Warning',
                        });
                        return 100;
                    }
                    return p + 2;
                });
            }, 50);
        }
    }, [scanning]);

    return (
        <div className="space-y-6 animate-fade-in">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="font-display text-3xl font-bold text-white flex items-center gap-3">
                        <Camera className="w-8 h-8 text-cyan-400" /> AI Water Scanner
                    </h1>
                    <p className="text-gray-400 mt-1">Real-time optical analysis for microplastics density</p>
                </div>
            </div>

            <div className="grid lg:grid-cols-2 gap-6">
                {/* Scanner Interface */}
                <div className="glass-card p-6 flex flex-col items-center justify-center min-h-[400px] relative overflow-hidden">
                    {!scanning && !result ? (
                        <div className="text-center">
                            <div className="w-24 h-24 rounded-full bg-cyan-500/10 flex items-center justify-center mx-auto mb-4 border-2 border-cyan-500/20">
                                <Camera className="w-10 h-10 text-cyan-400" />
                            </div>
                            <h3 className="text-xl font-bold text-white mb-2">Ready to Scan</h3>
                            <p className="text-sm text-gray-400 mb-6">Place sample in front of the lens</p>
                            <button onClick={startScan} className="btn-primary flex items-center gap-2 mx-auto">
                                <RefreshCw className="w-4 h-4" /> Start Analysis
                            </button>
                        </div>
                    ) : scanning ? (
                        <div className="w-full text-center space-y-6">
                            <div className="relative w-48 h-48 mx-auto border-4 border-cyan-500/30 rounded-full flex items-center justify-center overflow-hidden">
                                <div className="absolute inset-0 bg-cyan-500/20 animate-pulse" />
                                <div
                                    className="absolute bottom-0 left-0 right-0 bg-cyan-500/40"
                                    style={{ height: `${progress}%`, transition: 'height 0.1s linear' }}
                                />
                                <div className="relative z-10 font-mono text-3xl font-bold text-white">{progress}%</div>
                            </div>
                            <p className="text-cyan-400 font-bold animate-pulse uppercase tracking-widest text-sm">Analyzing optical refractions...</p>
                        </div>
                    ) : (
                        <div className="text-center space-y-6 w-full">
                            <div className={`w-24 h-24 rounded-full flex items-center justify-center mx-auto border-4 shadow-lg ${result.status === 'Safe' ? 'bg-emerald-500/10 border-emerald-500 shadow-emerald-500/20 text-emerald-400' : 'bg-orange-500/10 border-orange-500 shadow-orange-500/20 text-orange-400'}`}>
                                {result.status === 'Safe' ? <ShieldCheck className="w-12 h-12" /> : <AlertTriangle className="w-12 h-12" />}
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                                    <div className="text-xs text-gray-500 uppercase tracking-wider font-bold mb-1">Purity Level</div>
                                    <div className="text-2xl font-bold text-white">{result.purity}%</div>
                                </div>
                                <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                                    <div className="text-xs text-gray-500 uppercase tracking-wider font-bold mb-1">Microplastics</div>
                                    <div className="text-2xl font-bold text-white">{result.microplastics} <span className="text-xs text-gray-500">p/L</span></div>
                                </div>
                            </div>

                            <button onClick={startScan} className="btn-secondary w-full">Scan Another Sample</button>
                        </div>
                    )}
                </div>

                {/* Instructions / Info */}
                <div className="space-y-6">
                    <div className="glass-card p-6">
                        <h3 className="font-display font-bold text-white mb-4 flex items-center gap-2">
                            <Layers className="w-5 h-5 text-purple-400" /> Scanning Protocol
                        </h3>
                        <ul className="space-y-4 text-sm text-gray-300">
                            <li className="flex items-start gap-3">
                                <div className="w-6 h-6 rounded-full bg-purple-500/20 text-purple-400 flex items-center justify-center flex-shrink-0 font-bold">1</div>
                                <p>Ensure the water sample is placed in a clear, un-tinted glass container.</p>
                            </li>
                            <li className="flex items-start gap-3">
                                <div className="w-6 h-6 rounded-full bg-purple-500/20 text-purple-400 flex items-center justify-center flex-shrink-0 font-bold">2</div>
                                <p>Position the camera lens exactly 10 cm away from the container.</p>
                            </li>
                            <li className="flex items-start gap-3">
                                <div className="w-6 h-6 rounded-full bg-purple-500/20 text-purple-400 flex items-center justify-center flex-shrink-0 font-bold">3</div>
                                <p>Maintain a stable light source to avoid inaccurate particle detection.</p>
                            </li>
                        </ul>
                    </div>

                    <div className="glass-card p-6 bg-blue-500/5">
                        <h3 className="font-display font-bold text-white mb-2 flex items-center gap-2">
                            <Droplets className="w-5 h-5 text-blue-400" /> System Status
                        </h3>
                        <p className="text-sm text-gray-400 mb-4">AI model calibrated and ready to process high-resolution optical data for microplastic density.</p>
                        <div className="flex justify-between items-center text-xs text-gray-500">
                            <span>Last Calibration: 2 mins ago</span>
                            <span className="text-emerald-400 font-bold">✓ Optimal</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
