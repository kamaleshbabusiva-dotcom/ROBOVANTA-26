import { createContext, useContext, useState, useEffect } from 'react'

const LanguageContext = createContext({})

export const useLanguage = () => useContext(LanguageContext)

export const languages = [
    { code: 'en', name: 'English', flag: '🇺🇸' },
    { code: 'es', name: 'Español', flag: '🇪🇸' },
    { code: 'fr', name: 'Français', flag: '🇫🇷' },
    { code: 'de', name: 'Deutsch', flag: '🇩🇪' },
    { code: 'hi', name: 'हिन्दी', flag: '🇮🇳' },
    { code: 'zh', name: '中文', flag: '🇨🇳' },
    { code: 'ar', name: 'العربية', flag: '🇸🇦' },
    { code: 'ta', name: 'தமிழ்', flag: '🇮🇳' },
]

const translations = {
    en: {
        login: 'Login',
        try_demo: 'Try Demo',
        continue_google: 'Continue with Google',
        hero_title_1: 'Detecting the Invisible,',
        hero_title_2: 'Protecting Our Water',
        hero_desc: 'Combat microplastic pollution with AI-powered detection. Monitor water purity, file complaints, and join the global movement for cleaner oceans and rivers.',
        rev_wellness: 'Revolutionizing Water Purity Analysis',
        connecting: 'Connecting...',
        setup_info: 'Real-time analysis • IoT Integrated • Enterprise ready',
        features: {
            title1: 'Smart Water Analysis',
            desc1: 'AI-powered detection of microplastics and contaminants in real-time',
            title2: 'Global Purity Rankings',
            desc2: 'Track and compare water quality standards across regions and rivers',
            title3: 'Pollution Community',
            desc3: 'Connect with environmentalists and share local water quality findings',
            title4: 'Complaint Dashboard',
            desc4: 'Report water quality issues directly to local authorities and tracking agencies',
            title5: 'Purity Waveforms',
            desc5: 'Analyze water vibration patterns and acoustic purity signatures',
            title6: 'Advanced Analytics',
            desc6: 'Deep dive into microplastic density trends and chemical compositions',
        },
        stats: {
            users: 'Active Detectors',
            steps: 'Pollution Reduction',
            active: 'Water Safety Rate',
            sick: 'Fewer Contamination Incidents',
        },
        profile: {
            title: 'Water Security Profile',
            age: 'Certification Level',
            streak: 'day monitoring streak',
            achievements: 'certificates earned',
            today: 'Today',
            week: 'Week',
            month: 'Month',
            goals: 'Daily Water Parameters',
            daily_goal: 'pH Testing Samples',
            weekly_goal: 'Turbidity Reports',
            monthly_goal: 'Chemical Analysis',
            calc_based: 'Targets based on:',
            safety: 'Action Protocols',
            emergency: 'Crisis Contact (Pollution Control)',
            gps: 'Sensor Location:',
            gps_active: 'Active',
            locations: 'monitored sites saved',
            gallery: 'Certification Gallery',
            history: '30-Day Purity History',
            lang_settings: 'Language Settings',
            lang_desc: 'Select your preferred language',
            level: 'Rank',
            profession: 'Specialty',
            health: 'Purity Score'
        },
        chatbot: {
            header: 'AQUA AI',
            online: 'Online',
            placeholder: 'Inquire about water or health...',
            welcome: "Hello! I'm your AquaPure assistant. How can I help you analyze water or stay healthy today?",
            need_help: 'Need assistance?',
            drag_me: 'Position me!',
            responses: {
                hi: "Hello! Ready to conduct some water quality tests or discuss health tips?",
                workout: "You can view your sampling protocols in the Protocols tab.",
                music: "The Acoustic Analytics tool helps you analyze spectral signatures of water.",
                stats: "Historical purity data is available in the Purity Trends page.",
                leaderboard: "Check the Global Rankings to see how your region's water compares.",
                health: "For health safety: Do not drink water without proper filtration. Use a high-quality filter to remove microplastics and prefer boiled water. Avoid plastic containers; use steel or glass bottles instead. Check the 'AI Scanner' for personal purity reports.",
                water: "To protect our resources: Report contaminated sources to local authorities immediately. Avoid washing plastic items in water bodies. Use eco-friendly products and participate in community clean-ups. Use 'Incident Reports' to log issues.",
                microplastics: "Microplastics are tiny plastic particles under 5mm. Our AI helps detect them using infrared spectroscopy. Always use proper filtration to remove these harmful contaminants.",
                default: "I can help you with microplastic detection, water reporting, health tips, and purity analysis. Ask me anything!"
            }
        }
    },
    es: {
        login: 'Iniciar sesión',
        try_demo: 'Probar Demo',
        continue_google: 'Continuar con Google',
        hero_title_1: 'Tus Pasos,',
        hero_title_2: 'Tu Historia',
        hero_desc: 'Convierte cada paso en un logro. Compite en tablas de clasificación, conéctate con colegas y transforma tus días de trabajo en victorias.',
        rev_wellness: 'Revolucionando el Bienestar Corporativo',
        connecting: 'Conectando...',
        setup_info: 'Configuración en 30 segundos • Sin tarjeta • Listo para empresas',
        features: {
            title1: 'Seguimiento Inteligente',
            desc1: 'Metas personalizadas según edad, profesión y habilidad',
            title2: 'Tabla Estilo Duolingo',
            desc2: 'Zonas Esmeralda → Bronce con batallas de ascenso',
            title3: 'Centro Social',
            desc3: 'Chat, ajedrez, desafíos grupales con colegas',
            title4: 'Seguridad de Emergencia',
            desc4: 'Botón SOS, rastreo GPS, contactos de emergencia',
            title5: 'Ritmos de Caminata',
            desc5: 'Listas de reproducción sincronizadas con tu ritmo',
            title6: 'Análisis Personalizado',
            desc6: 'Gráficos de salud específicos por edad y trabajo',
        },
        stats: {
            users: 'Usuarios Corporativos',
            steps: 'Aumento de Pasos Diarios',
            active: 'Tasa de Actividad Semanal',
            sick: 'Menos Días de Enfermedad',
        },
        profile: {
            title: 'Perfil',
            age: 'Edad',
            streak: 'días de racha',
            achievements: 'logros',
            today: 'Hoy',
            week: 'Semana',
            month: 'Mes',
            goals: 'Metas de Pasos Personalizadas',
            daily_goal: 'Meta Diaria',
            weekly_goal: 'Meta Semanal',
            monthly_goal: 'Meta Mensual',
            calc_based: 'Metas calculadas en base a:',
            safety: 'Información de Seguridad',
            emergency: 'Contacto de Emergencia',
            gps: 'Rastreo GPS:',
            gps_active: 'Activo',
            locations: 'ubicaciones favoritas guardadas',
            gallery: 'Galería de Logros',
            history: 'Historial de 30 Días',
            lang_settings: 'Ajustes de Idioma',
            lang_desc: 'Selecciona tu idioma preferido',
            level: 'Nivel',
            profession: 'Profesión',
            health: 'Salud'
        },
        chatbot: {
            header: 'FOXHOUND AI',
            online: 'En línea',
            placeholder: 'Escribe un mensaje...',
            welcome: "¡Hola! Soy tu asistente FOXHOUND. ¿Cómo puedo ayudarte hoy?",
            need_help: '¿Necesitas ayuda?',
            drag_me: '¡Arrástrame!',
            responses: {
                hi: "¡Hola! ¿Listo para aplastar tus metas de fitness?",
                workout: "Puedes revisar tus rutinas diarias en la pestaña Planner. ¿Necesitas ayuda para configurar una?",
                music: "¡El reproductor de música en la parte inferior te permite escuchar tus pistas favoritas mientras entrenas!",
                stats: "Tu progreso se registra en la página de Stats. ¡Sigue adelante!",
                leaderboard: "Consulta la Leaderboard para ver cómo te sitúas frente a otros miembros de FOXHOUND.",
                default: "¡Esa es una gran pregunta! Todavía estoy aprendiendo, pero puedo ayudarte a navegar por FOXHOUND. ¡Prueba a preguntar sobre entrenamientos, música o estadísticas!"
            }
        }
    },
    hi: {
        login: 'लॉगिन',
        try_demo: 'डेमो आज़माएं',
        continue_google: 'Google के साथ आगे बढ़ें',
        hero_title_1: 'आपके कदम,',
        hero_title_2: 'आपकी कहानी',
        hero_desc: 'हर कदम को एक उपलब्धि में बदलें। लीडरबोर्ड पर प्रतिस्पर्धा करें, सहकर्मियों से जुड़ें और अपने कार्यदिवसों को जीत में बदलें।',
        rev_wellness: 'कॉर्पोरेट कल्याण में क्रांति',
        connecting: 'जुड़ रहा है...',
        setup_info: '30-सेकंड सेटअप • कोई क्रेडिट कार्ड नहीं • एंटरप्राइज़ तैयार',
        features: {
            title1: 'स्मार्ट स्टेप ट्रैकिंग',
            desc1: 'आयु, पेशे और क्षमता के आधार पर व्यक्तिगत लक्ष्य',
            title2: 'डुओलिंगो-शैली लीडरबोर्ड',
            desc2: 'पदोन्नति की लड़ाई के साथ एमराल्ड → ब्रोंज जोन',
            title3: 'सोशल हब',
            desc3: 'सहकर्मियों के साथ चैट, शतरंज, समूह चुनौतियाँ',
            title4: 'आपातकालीन सुरक्षा',
            desc4: 'एसओएस बटन, जीपीएस ट्रैकिंग, आपातकालीन संपर्क',
            title5: 'वॉकिंग बीट्स',
            desc5: 'आपकी गति के साथ समन्वयित क्यूरेटेड प्लेलिस्ट',
            title6: 'कस्टम एनालिटिक्स',
            desc6: 'आयु और नौकरी-विशिष्ट स्वास्थ्य चार्ट',
        },
        stats: {
            users: 'सक्रिय डिटेक्टर',
            steps: 'प्रदूषण में कमी',
            active: 'जल सुरक्षा दर',
            sick: 'कम संदूषण घटनाएँ',
        },
        profile: {
            title: 'जल सुरक्षा प्रोफ़ाइल',
            age: 'प्रमाणन स्तर',
            streak: 'दिनों की निगरानी निरंतरता',
            achievements: 'अर्जित प्रमाण पत्र',
            today: 'आज',
            week: 'सप्ताह',
            month: 'महीना',
            goals: 'दैनिक जल मापदंड',
            daily_goal: 'pH परीक्षण नमूने',
            weekly_goal: 'टर्बिडिटी रिपोर्ट',
            monthly_goal: 'रासायनिक विश्लेषण',
            calc_based: 'लक्ष्य इनके आधार पर हैं:',
            safety: 'सुरक्षा प्रोटोकॉल',
            emergency: 'आपातकालीन संपर्क',
            gps: 'सेंसर स्थान:',
            gps_active: 'सक्रिय',
            locations: 'निगरानी स्थल सहेजे गए',
            gallery: 'प्रमाणन गैलरी',
            history: '30-दिन का शुद्धता इतिहास',
            lang_settings: 'भाषा सेटिंग',
            lang_desc: 'अपनी पसंदीदा भाषा चुनें',
            level: 'स्तर',
            profession: 'विशेषज्ञता',
            health: 'शुद्धता स्कोर'
        },
        chatbot: {
            header: 'एक्वा AI',
            online: 'ऑनलाइन',
            placeholder: 'पानी या स्वास्थ्य के बारे में पूछें...',
            welcome: "नमस्ते! मैं आपका एक्वाप्योर सहायक हूँ। मैं आज पानी के विश्लेषण या स्वस्थ रहने में आपकी कैसे मदद कर सकता हूँ?",
            need_help: 'मदद चाहिए?',
            drag_me: 'मुझे खींचें!',
            responses: {
                hi: "नमस्ते! जल गुणवत्ता परीक्षण करने या स्वास्थ्य युक्तियों पर चर्चा करने के लिए तैयार हैं?",
                workout: "आप प्रोटोकॉल टैब में अपने नमूना प्रोटोकॉल देख सकते हैं।",
                music: "ध्वनिक विश्लेषण टूल पानी के स्पेक्ट्रल हस्ताक्षरों का विश्लेषण करने में मदद करता है।",
                stats: "ऐतिहासिक शुद्धता डेटा शुद्धता रुझान (Purity Trends) पेज में उपलब्ध है।",
                leaderboard: "ग्लोबल रैंकिंग देखें कि आपके क्षेत्र का पानी दूसरों की तुलना में कैसा है।",
                water: "जल सुरक्षा के लिए: दूषित जल स्रोतों की सूचना तुरंत स्थानीय अधिकारियों को दें। जलाशयों में प्लास्टिक की वस्तुएं न धोएं। पर्यावरण के अनुकूल उत्पादों का उपयोग करें और सामुदायिक स्वच्छता अभियानों में भाग लें। रिपोर्ट के लिए 'Incident Reports' टैब का उपयोग करें।",
                health: "स्वास्थ्य सुरक्षा के लिए: उचित निस्पंदन (filtration) के बिना पानी न पिएं। माइक्रोप्लास्टिक हटाने के लिए उच्च गुणवत्ता वाले फिल्टर का उपयोग करें और उबला हुआ पानी पसंद करें। प्लास्टिक की बोतलों के बजाय स्टील या कांच का उपयोग करें।",
                microplastics: "माइक्रोप्लास्टिक 5 मिमी से कम के छोटे प्लास्टिक कण हैं। हमारा AI स्पेक्ट्रोस्कोपी का उपयोग करके उनका पता लगाता है। इनसे बचने के लिए हमेशा फ़िल्टर किए हुए पानी का उपयोग करें।",
                default: "मैं माइक्रोप्लास्टिक डिटेक्शन, रिपोर्टिंग और स्वास्थ्य युक्तियों में आपकी मदद कर सकता हूँ। कुछ भी पूछें!"
            }
        }
    },
    fr: {
        login: 'Connexion',
        try_demo: 'Essayer la démo',
        continue_google: 'Continuer avec Google',
        hero_title_1: 'Vos Pas,',
        hero_title_2: 'Votre Histoire',
        hero_desc: 'Transformez chaque pas en réussite. Participez aux classements, connectez-vous avec vos collègues et transformez vos journées de travail en victoires.',
        rev_wellness: 'Révolutionner le bien-être en entreprise',
        connecting: 'Connexion...',
        setup_info: 'Configuration en 30s • Sans carte • Prêt pour l\'entreprise',
        features: {
            title1: 'Suivi Intelligent',
            desc1: 'Objectifs personnalisés selon l\'âge, la profession et les capacités',
            title2: 'Classement Style Duolingo',
            desc2: 'Zones Émeraude → Bronze avec batailles de promotion',
            title3: 'Hub Social',
            desc3: 'Chat, échecs, défis de groupe avec des collègues',
            title4: 'Sécurité d\'Urgence',
            desc4: 'Bouton SOS, suivi GPS, contacts d\'urgence',
            title5: 'Rythmes de Marche',
            desc5: 'Playlists adaptées à votre allure',
            title6: 'Analyses Personnalisées',
            desc6: 'Graphiques de santé par âge et par métier',
        },
        stats: {
            users: 'Utilisateurs en Entreprise',
            steps: 'Augmentation des Pas Quotidiens',
            active: 'Taux d\'Activité Hebdomadaire',
            sick: 'Moins de Jours de Maladie',
        },
        profile: {
            title: 'Profil',
            age: 'Âge',
            streak: 'jours de série',
            achievements: 'succès',
            today: 'Aujourd\'hui',
            week: 'Semaine',
            month: 'Mois',
            goals: 'Objectifs de Pas Personnalisés',
            daily_goal: 'Objectif Quotidien',
            weekly_goal: 'Objectif Hebdomadaire',
            monthly_goal: 'Objectif Mensuel',
            calc_based: 'Objectifs calculés selon:',
            safety: 'Informations de Sécurité',
            emergency: 'Contact d\'Urgence',
            gps: 'Suivi GPS:',
            gps_active: 'Actif',
            locations: 'lieux favoris enregistrés',
            gallery: 'Galerie de Succès',
            history: 'Historique sur 30 Jours',
            lang_settings: 'Paramètres de Langue',
            lang_desc: 'Sélectionnez votre langue préférée',
            level: 'Niveau',
            profession: 'Profession',
            health: 'Santé'
        },
        chatbot: {
            header: 'FOXHOUND AI',
            online: 'En ligne',
            placeholder: 'Tapez un message...',
            welcome: "Bonjour ! Je suis votre assistant FOXHOUND. Comment puis-je vous aider aujourd'hui ?",
            need_help: 'Besoin d\'aide ?',
            drag_me: 'Faites-moi glisser !',
            responses: {
                hi: "Bonjour ! Prêt à atteindre vos objectifs de fitness ?",
                workout: "Vous pouvez consulter vos routines quotidiennes dans l'onglet Planner. Besoin d'aide pour en configurer une ?",
                music: "Le lecteur de musique en bas vous permet d'écouter vos morceaux préférés pendant l'entraînement !",
                stats: "Vos progrès sont suivis sur la page Stats. Continuez comme ça !",
                leaderboard: "Consultez le Leaderboard pour voir votre classement par rapport aux autres membres de FOXHOUND.",
                default: "C'est une excellente question ! J'apprends encore, mais je peux vous aider à naviguer dans FOXHOUND. Essayez de poser des questions sur les entraînements, la musique ou les statistiques !"
            }
        }
    },
    ta: {
        login: 'உள்நுழை',
        try_demo: 'டெமோ முயற்சிக்கவும்',
        continue_google: 'கூகுள் மூலம் தொடரவும்',
        hero_title_1: 'உங்கள் அடிகள்,',
        hero_title_2: 'உங்கள் கதை',
        hero_desc: 'ஒவ்வொரு அடியையும் ஒரு சாதனையாக மாற்றவும். லீடர்போர்டுகளில் போட்டியிடுங்கள், சக ஊழியர்களுடன் இணையுங்கள்.',
        rev_wellness: 'கார்ப்பரேட் ஆரோக்கியத்தில் புரட்சியை ஏற்படுத்துகிறது',
        connecting: 'இணைக்கிறது...',
        setup_info: '30-வினாடி அமைப்பு • கிரெடிட் கார்டு இல்லை • நிறுவனத்திற்கு தயார்',
        features: {
            title1: 'ஸ்மார்ட் ஸ்டெப் டிராக்கிங்',
            desc1: 'வயது, தொழில் மற்றும் திறனின் அடிப்படையில் தனிப்பயனாக்கப்பட்ட இலக்குகள்',
            title2: 'டூயாலிங்கோ-பாணி லீடர்போர்டு',
            desc2: 'பதவி உயர்வு போர்களுடன் எமரால்டு → வெண்கல மண்டலங்கள்',
            title3: 'சமூக மையம்',
            desc3: 'சக ஊழியர்களுடன் அரட்டை, சதுரங்கம், குழு சவால்கள்',
            title4: 'அவசர பாதுகாப்பு',
            desc4: 'SOS பொத்தான், GPS டிராக்கிங், அவசர தொடர்புகள்',
            title5: 'வாக்கிங் பீட்ஸ்',
            desc5: 'உங்கள் வேகத்திற்கு ஏற்ப தேர்ந்தெடுக்கப்பட்ட பிளேலிஸ்ட்கள்',
            title6: 'தனிப்பயன் பகுப்பாய்வு',
            desc6: 'வயது மற்றும் பணி சார்ந்த சுகாதார விளக்கப்படங்கள்',
        },
        stats: {
            users: 'செயலில் உள்ள கண்டுபிடிப்பாளர்கள்',
            steps: 'மாசு குறைப்பு',
            active: 'நீர் பாதுகாப்பு விகிதம்',
            sick: 'குறைவான மாசு நிகழ்வுகள்',
        },
        profile: {
            title: 'நீர் பாதுகாப்பு சுயவிவரம்',
            age: 'சான்றிதழ் நிலை',
            streak: 'நாள் கண்காணிப்பு தொடர்ச்சி',
            achievements: 'பெற்ற சான்றிதழ்கள்',
            today: 'இன்று',
            week: 'வாரம்',
            month: 'மாதம்',
            goals: 'தினசரி நீர் அளவீடுகள்',
            daily_goal: 'pH சோதனை மாதிரிகள்',
            weekly_goal: 'நீர் கலங்கல் அறிக்கைகள்',
            monthly_goal: 'வேதியியல் பகுப்பாய்வு',
            calc_based: 'இலக்குகள் இதன் அடிப்படையில் கணக்கிடப்படுகின்றன:',
            safety: 'பாதுகாப்பு நெறிமுறைகள்',
            emergency: 'ஆவசர தொடர்பு (மாசு கட்டுப்பாடு)',
            gps: 'சென்சார் இருப்பிடம்:',
            gps_active: 'செயலில்',
            locations: 'கண்காணிக்கப்படும் இடங்கள்',
            gallery: 'சான்றிதழ் தொகுப்பு',
            history: '30-நாள் தூய்மை வரலாறு',
            lang_settings: 'மொழி அமைப்புகள்',
            lang_desc: 'விருப்பமான மொழியைத் தேர்ந்தெடுக்கவும்',
            level: 'நிலை',
            profession: 'தொழில்',
            health: 'தூய்மை மதிப்பெண்'
        },
        chatbot: {
            header: 'அக்வா AI',
            online: 'ஆன்லைனில்',
            placeholder: 'நீர் அல்லது ஆரோக்கியம் பற்றி கேட்கவும்...',
            welcome: "வணக்கம்! நான் உங்கள் அக்வாபியூர் உதவியாளர். இன்று நீர் பகுப்பாய்வில் அல்லது ஆரோக்கியமாக இருக்க நான் உங்களுக்கு எப்படி உதவ முடியும்?",
            need_help: 'உதவி தேவையா?',
            drag_me: 'என்னை இழுக்கவும்!',
            responses: {
                hi: "வணக்கம்! நீர் தர சோதனைகளை நடத்த அல்லது ஆரோக்கிய குறிப்புகளைப் பற்றி பேச தயாரா?",
                workout: "உங்கள் மாதிரி நெறிமுறைகளை நெறிமுறை தாவலில் பார்க்கலாம்.",
                music: "ஒலி பகுப்பாய்வு கருவி நீரின் அதிர்வு சமிக்ஞைகளை பகுப்பாய்வு செய்ய உதவுகிறது.",
                stats: "தூய்மை வரலாறு புள்ளிவிவர பக்கத்தில் உள்ளது.",
                leaderboard: "உலகளாவிய தரவரிசையில் உங்கள் பகுதி நீரை ஒப்பிட்டுப் பாருங்கள்.",
                water: "நீர் ஆதாரங்களைப் பாதுகாக்க: மாசுபட்ட நீர் ஆதாரங்கள் குறித்து உடனடியாக அதிகாரிகளுக்குத் தெரிவிக்கவும். நீர்நிலைகளில் பிளாஸ்டிக் பொருட்களைக் கழுவுவதைத் தவிர்க்கவும். 'Incident Reports' தாவலைப் பயன்படுத்தவும்.",
                health: "ஆரோக்கியத்திற்கு: முறையான வடிகட்டுதல் (filtration) இல்லாமல் தண்ணீரைக் குடிக்க வேண்டாம். மைக்ரோபிளாஸ்டிக்கை அகற்ற உயர்தர வடிப்பான்களைப் பயன்படுத்தவும். பிளாஸ்டிக் பாட்டில்களுக்குப் பதிலாக எஃகு (steel) அல்லது கண்ணாடி பாட்டில்களைப் பயன்படுத்தவும்.",
                microplastics: "மைக்ரோபிளாஸ்டிக் என்பது 5மிமீ க்கும் குறைவான சிறிய பிளாஸ்டிக் துகள்கள். எப்போதும் பாதுகாப்பான மற்றும் வடிகட்டப்பட்ட நீரையே பயன்படுத்தவும்.",
                default: "மைக்ரோபிளாஸ்டிக் கண்டறிதல், நீர் தரம் மற்றும் ஆரோக்கிய குறிப்புகள் பற்றி நான் உங்களுக்கு உதவ முடியும். எது வேண்டுமானாலும் கேளுங்கள்!"
            }
        }
    }
}

export const LanguageProvider = ({ children }) => {
    const [currentLanguage, setCurrentLanguage] = useState(() => {
        const saved = localStorage.getItem('app_language')
        return saved || 'en'
    })

    useEffect(() => {
        localStorage.setItem('app_language', currentLanguage)
        // Set document direction for RTL languages like Arabic
        document.dir = currentLanguage === 'ar' ? 'rtl' : 'ltr'
    }, [currentLanguage])

    const t = (path) => {
        const keys = path.split('.')
        let result = translations[currentLanguage] || translations['en']

        for (const key of keys) {
            if (result[key]) {
                result = result[key]
            } else {
                // Fallback to English if key missing
                let fallback = translations['en']
                for (const fk of keys) {
                    fallback = fallback?.[fk]
                }
                return fallback || path
            }
        }
        return result
    }

    return (
        <LanguageContext.Provider value={{ currentLanguage, setCurrentLanguage, t, languages }}>
            {children}
        </LanguageContext.Provider>
    )
}
