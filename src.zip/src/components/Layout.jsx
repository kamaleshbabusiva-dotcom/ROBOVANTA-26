import React from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';
import TopBar from './TopBar';
import MusicPlayer from './MusicPlayer';
import Chatbot from './Chatbot';

const Layout = () => {
    return (
        <div className="flex min-h-screen bg-dark-950 text-white font-sans">
            {/* Sidebar */}
            <Sidebar />

            {/* Main Content Area */}
            <div className="flex-1 flex flex-col min-w-0 ml-64">
                {/* Top Navigation */}
                <TopBar />

                {/* Page Content */}
                <main className="flex-1 p-6 pb-32 overflow-x-hidden">
                    <div className="max-w-7xl mx-auto">
                        <Outlet />
                    </div>
                </main>

                {/* Music Player (Fixed at bottom) */}
                <MusicPlayer />

                {/* Chatbot (Floating) */}
                <Chatbot />
            </div>
        </div>
    );
};

export default Layout;
